function manyChecks() {
  let a = Math.floor(Math.random() * 20) + 1;
  console.log(`a = ${a}`);

  // ориг терн.оператор
  // return (
  //   a > 10 ? 'a больше 10' : 'a меньше или равно 10 ' + (a === 5 ? 'пример особого случая' : ''))
  //   + (a === 15 ? 'но a не 15' : '')
  //   + (a > 5 ? ' и a больше 5' : ' и a меньше или равно 5 ')
  //   + (a % 2 ? ' и a нечетное' : ' и a четное ');

  // if/else
  function manyChecksIfElse(a) {
    let result = '';

    // 1: a > 10
    if (a > 10) {
      result += 'a больше 10';
    } else {
      result += 'a меньше или равно 10 ';
      // 1а: a === 5 (вложил в else)
      if (a === 5) {
        result += 'пример особого случая';
      }
    }

    // 2: a === 15
    if (a === 15) {
      result += 'но a не 15';
    }

    // 3: a > 5
    if (a > 5) {
      result += ' и a больше 5';
    } else {
      result += ' и a меньше или равно 5 ';
    }

    // 4: четность
    if (a % 2) {
      result += ' и a нечетное';
    } else {
      result += ' и a четное ';
    }

    return result;
  }

  console.log("IF...ELSE результат:", manyChecksIfElse(a));

  // свичи
  function manyChecksSwitch(a) {
    let result = '';

    // 1: a > 10
    switch (true) {
      case a > 10:
        result += 'a больше 10';
        break;
      default:
        result += 'a меньше или равно 10 ';
        // 1а: a === 5
        switch (a) {
          case 5:
            result += 'пример особого случая';
            break;
        }
    }

    // 2: a === 15
    switch (a) {
      case 15:
        result += 'но a не 15';
        break;
    }

    // 3: a > 5
    switch (true) {
      case a > 5:
        result += ' и a больше 5';
        break;
      default:
        result += ' и a меньше или равно 5 ';
    }

    // 4: чётность
    switch (a % 2 !== 0) {
      case true:
        result += ' и a нечетное';
        break;
      default:
        result += ' и a четное ';
    }

    return result;
  }

  console.log("SWITCH результат:", manyChecksSwitch(a));
}

manyChecks();